#include <iostream>
#include <fstream>
#include <openssl\bn.h>
#include <openssl\applink.c>
using namespace std;
__declspec(dllexport) void **OPENSSL_Applink();
typedef unsigned char byte; 

	int egcd(int a, int b, int *x, int *y) 
	{ 
		// Base Case 
		if (a == 0) 
		{ 
			*x = 0; 
			*y = 1; 
			return b; 
		} 
  
		int x1, y1; // To store results of recursive call 
		int gcd = egcd(b%a, a, &x1, &y1); 
  
		// Update x and y using results of recursive 
		// call 
		*x = y1 - (b/a) * x1; 
		*y = x1; 
  
		return gcd; 
	} 
	void get_mess(BIGNUM *c1, BIGNUM *c2, BIGNUM *mod)
	{
		int x,y,exp1 = 7,exp2 = 5;
		BN_CTX *ctx = BN_CTX_new();
		if(egcd(exp1,exp2,&x,&y) != 1)
			cout<<"nu sunt c-prime";
		BIGNUM *e1 = BN_new();
		BIGNUM *e2 = BN_new();
		BIGNUM *pe1 = BN_new();
		BIGNUM *pe2 = BN_new();
		BIGNUM *ie = BN_new();
		BIGNUM *m = BN_new();
		BN_set_word(e1,(unsigned int)abs(x));
		BN_set_word(e2,(unsigned int)abs(y));
		BN_mod_inverse(ie, c1,mod,ctx);
		BN_print_fp(stdout,ie);
		cout<<endl;
		//BN_mod_exp(pe1,c1,e1,mod,ctx);//(pe1,c1,e1,ctx);
		//BN_mod_exp(pe2,c2,ie2,mod,ctx);
		BN_mod_exp(pe1,ie,e1,mod,ctx);
		BN_mod_exp(pe2,c2,e2,mod,ctx);
		BN_mod_mul(m,pe1,pe2,mod,ctx);
		FILE *f = fopen("fout.out","wb");
		BN_print_fp(f,m);
		fclose(f);
		BN_free(e1);
		BN_free(e2);
		BN_free(pe1);
		BN_free(pe1);
		BN_free(ie);
		BN_free(m);
		BN_CTX_free(ctx);


	}

int main()
{
	BIGNUM *mod = BN_new();
	BIGNUM *c1 = BN_new();
	BIGNUM *c2 = BN_new();
	byte buff[1050];
	FILE *f = fopen("modul.in","rb");
	fread(buff,sizeof(byte),256,f);
	fclose(f);
	BN_hex2bn(&mod,(const char*)buff);
	f = fopen("c1.in","rb");
	fread(buff,sizeof(byte),256,f);
	fclose(f);
	BN_hex2bn(&c1,(const char*)buff);
	f = fopen("c2.in","rb");
	fread(buff,sizeof(byte),256,f);
	fclose(f);
	BN_hex2bn(&c2,(const char*)buff);

	BN_print_fp(stdout,c1);
	cout<<endl;
	BN_print_fp(stdout,c2);
	cout<<endl;
	BN_print_fp(stdout,mod);
	cout<<endl;

	get_mess(c1,c2,mod);

	BN_free(mod);
	BN_free(c1);
	BN_free(c2);
	
}